package com.the703.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.the703.dto.BoardDto;
import com.the703.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	BoardService service;

	// �� ��ü ����Ʈ
	@RequestMapping("/board/list.do")
	public String list(Model model) {
		model.addAttribute("list", service.selectAll());
		return "board/list";
	}

	public String list() {
		return "board/list";
	}

	// �� �۾��� �����
	@RequestMapping(value = "/board/write.do", method = RequestMethod.GET)
	public String write(Model model) {
		model.addAttribute("list", service.selectAll());
		return "/board/write";
	}

	// �� �� ���� ���
	@RequestMapping(value = "/board/write.do", method = RequestMethod.POST)
	public String write_post(BoardDto dto, RedirectAttributes rttr) {
		String result = "�۾��� ����";

		if (service.insert(dto) > 0) {
			result = "�۾��� ����";
		}
		rttr.addFlashAttribute("result", result);
		return "redirect:/board/list.do";
	}
	// �� �� �󼼺���

	@RequestMapping("/board/detail.do")
	public String detail(int bno, Model model) {
		model.addAttribute("dto", service.detail(bno));
		return "board/detail";
	}

	public String detail() {
		return "/board/detail";
	}

	// �� �� ���� �����
	@RequestMapping(value = "/board/edit.do", method = RequestMethod.GET)
	public String edit(int bno, Model model) {
		// �Ѱܹ޴� bno , edit.jsp
		model.addAttribute("dto", service.editView(bno));
		return "board/edit";

	}

	// �� �� ���� ���
	@RequestMapping(value = "/board/edit.do", method = RequestMethod.POST)
	public String edit_post(BoardDto dto,String bpass, RedirectAttributes rttr) {
		String result = "��й�ȣ Ȯ��";
		if(dto.getBpass().equals(bpass)) {
			if (service.edit(dto) > 0) {
				result = "��������";
			}
		}else {
			result="��������";
		}
		
		rttr.addFlashAttribute("result", result);
		return "redirect:/board/detail.do?bno=" + dto.getBno();
	}

	// �� �� ���� �����
	@RequestMapping(value = "/board/delete.do", method = RequestMethod.GET)
	public String delete(int bno) {
//		model.addAttribute("dto",service.delete(bno));
		return "board/delete";

	}

	// �� �� ���� ���
	@RequestMapping(value = "/board/delete.do", method = RequestMethod.POST)
	public String delete_post(int bno, String bpass, RedirectAttributes rttr) {
		BoardDto dto = service.detail(bno);
//		BoardDto dto=new BoardDto();
		dto.setBno(bno);

		String result = "��й�ȣ Ȯ��";
		if (dto.getBpass().equals(bpass)) {
			if (service.delete(dto) > 0) {
				result = "���� ����";
			}
		} else {
			result = "���� ����";
		}

		rttr.addFlashAttribute("result", result);
		return "redirect:/board/list.do";
	}

}

package com.the703.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BasicController {
	@RequestMapping("/")
	public String index() {
		//����������- db ��Ʈ�ѷ� :index.jsp
		return "redirect:/board/list.do";
	}
	
	
	@RequestMapping("/basic.do")
	public String basic(Model model) {
		model.addAttribute("result","Hello");
		return "basic"; // /view/ +basic +.jsp
	}
	
	
}

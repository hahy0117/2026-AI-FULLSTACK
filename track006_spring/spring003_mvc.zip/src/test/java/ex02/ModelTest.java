package ex02;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.the703.dao.BoardMapper;
import com.the703.dao.TestMapper;
import com.the703.dto.BoardDto;
import com.the703.service.BoardService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/*-context.xml")
public class ModelTest {
	@Autowired
	ApplicationContext context;
	@Autowired
	DataSource dataSource;
	@Autowired
	SqlSession sqlSession;
	@Autowired
	TestMapper testMapper;
	@Autowired BoardMapper boardMapper;
	@Autowired BoardService service;
	/*
	 * @Test public void test1() { System.out.println(context); }
	 */
	   @Test
	   public void test5() {
	      //����
	      BoardDto dto = new BoardDto();   dto.setBno(4);
	      System.out.println(  service.delete(dto) );
	      //����
	      //      BoardDto dto = new BoardDto();
	      //      dto.setBname("first");        dto.setBpass("1111"); dto.setBno(4);
	      //      dto.setBtitle("NEW-service-ù��° �۾���");  dto.setBcontent("NEW-service-����");
	      //      System.out.println(  service.edit(dto) ); 
	      
	      //�˻�
	      System.out.println(service.detail(4)); 
	      //����  -  4
	      //      BoardDto dto = new BoardDto();
	      //      dto.setBname("first");        dto.setBpass("1111");
	      //      dto.setBtitle("service-ù��° �۾���");  dto.setBcontent("service-����");
	      //      System.out.println(  service.insert(dto) );
	      
	      //��ü����Ʈ
	      //System.out.println(service.selectAll());
	   }
	   

	@Ignore // @Test
	public void test2() {
		System.out.println(sqlSession);
	}

	@Ignore // @Test
	public void test3() {
		System.out.println(testMapper.now());
	}
	@Ignore // @Test
	public void test4() throws UnknownHostException {
		//����
		System.out.println(boardMapper.delete(1));
		//����
		BoardDto dto2=new BoardDto();
		dto2.setBname("first");
		dto2.setBtitle("ù��° �۾���"); 
		dto2.setBcontext("����");
		System.out.println(boardMapper.update(dto2));
		//�˻�
		System.out.println(boardMapper.select(1));
		
		//����
		BoardDto dto= new BoardDto();
		dto.setBname("first");
		dto.setBpass("1111");
		dto.setBtitle("ù���� �۾���");
		dto.setBcontext("����");
		dto.setBip(InetAddress.getLocalHost().getHostAddress());
		System.out.println(boardMapper.insert(dto));
		System.out.println(boardMapper.selectAll());
	}
	@Ignore // @Test
	public void test6() {
		BoardDto dto2=new BoardDto();
		dto2.setBtitle("first");
		dto2.setBcontext("ù��° �۾���"); 
		dto2.setBno(2);
		System.out.println(boardMapper.update(dto2));
	}
	
}

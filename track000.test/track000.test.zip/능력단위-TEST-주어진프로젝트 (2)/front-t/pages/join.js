import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

import {
    SIGN_UP_REQUEST,
    CHECK_EMAIL_REQUEST,
    CHECK_NICKNAME_REQUEST,
} from '../reducers/user';


export default function JoinPage(){

    const dispatch = useDispatch();
    const router = useRouter();

    const {
        me,
        isLoading,
        error,
        signUpDone,
        isEmailAvailable,
        checkEmailLoading,
        isNicknameAvailable,
        checkNicknameLoading,
    } = useSelector((state)=>state.user);


    const [email,setEmail] = useState('');
    const [password,setPassword] = useState('');
    const [nickname,setNickname] = useState('');


    // 이메일 중복 확인
    const onCheckEmail = (e)=>{
        e.preventDefault();

        if(!email.trim()){
            alert('이메일을 입력해주세요.');
            return;
        }

        dispatch({
            type: CHECK_EMAIL_REQUEST,
            data: email
        });
    };


    // 닉네임 중복 확인
    const onCheckNickname = (e)=>{
        e.preventDefault();

        if(!nickname.trim()){
            alert('닉네임을 입력해주세요.');
            return;
        }

        dispatch({
            type: CHECK_NICKNAME_REQUEST,
            data: nickname
        });
    };


    // 회원가입
    const onSubmit=(e)=>{
        e.preventDefault();


        if(!email.trim()){
            alert('이메일을 입력해주세요');
            return;
        }

        if(!password.trim()){
            alert('비밀번호를 입력해주세요');
            return;
        }

        if(!nickname.trim()){
            alert('닉네임을 입력해주세요');
            return;
        }


        dispatch({
            type:SIGN_UP_REQUEST,
            data:{
                email,
                password,
                nickname
            }
        });

    };



    useEffect(()=>{
        if(me){
            router.push('/users');
        }
    },[me,router]);



    useEffect(()=>{

        if(signUpDone){
            window.location.href='/login?signUpSuccess=true';
        }

    },[signUpDone,router]);



    return(
    <div className="container mt-4">

        <h2 className="mb-3">회원가입</h2>


        <form onSubmit={onSubmit} className="w-50 mx-auto">


        {/* 이메일 */}

        <div className="mb-3 input-group">

            <input
                type="email"
                className="form-control"
                placeholder="이메일"
                value={email}

                onChange={(e)=>{
                    setEmail(e.target.value);
                }}
            />


            <button
                className="btn btn-outline-secondary"
                type="button"
                onClick={onCheckEmail}
                disabled={checkEmailLoading}
            >
                {
                checkEmailLoading
                ? '확인 중...'
                : '중복 확인'
                }
            </button>


        </div>



        {
        isEmailAvailable === true &&
        <div className="text-success mb-2">
            사용 가능한 이메일입니다.
        </div>
        }



        {
        isEmailAvailable === false &&
        <div className="text-danger mb-2">
            이미 사용 중인 이메일입니다.
        </div>
        }




        {/* 비밀번호 */}

        <div className="mb-3">

            <input
                type="password"
                className="form-control"
                placeholder="비밀번호"
                value={password}

                onChange={(e)=>{
                    setPassword(e.target.value);
                }}

            />

        </div>





        {/* 닉네임 */}

        <div className="mb-3 input-group">


            <input
                type="text"
                className="form-control"
                placeholder="닉네임"
                value={nickname}

                onChange={(e)=>{
                    setNickname(e.target.value);
                }}

            />


            <button
                className="btn btn-outline-secondary"
                type="button"
                onClick={onCheckNickname}
                disabled={checkNicknameLoading}
            >

                {
                checkNicknameLoading
                ? '확인 중...'
                : '중복 확인'
                }

            </button>


        </div>




        {
        isNicknameAvailable === true &&
        <div className="text-success mb-2">
            사용 가능한 닉네임입니다.
        </div>
        }



        {
        isNicknameAvailable === false &&
        <div className="text-danger mb-2">
            이미 사용 중인 닉네임입니다.
        </div>
        }





        <button
            type="submit"
            className="btn btn-primary w-100"
            disabled={isLoading}
        >
            회원가입
        </button>


        </form>



        {
        error &&
        <div className="alert alert-danger mt-3">
            {error}
        </div>
        }


    </div>
    );

}
/**
 * reducers/user.js
 * ----------------------------------------------------
 * 사용자 관련 상태(user state)를 관리하는 리듀서
 */

// 액션 타입 정의
export const LOG_IN_REQUEST = 'LOG_IN_REQUEST';
export const LOG_IN_SUCCESS = 'LOG_IN_SUCCESS';
export const LOG_IN_FAILURE = 'LOG_IN_FAILURE';

export const LOG_OUT_REQUEST = 'LOG_OUT_REQUEST';
export const LOG_OUT_SUCCESS = 'LOG_OUT_SUCCESS';
export const LOG_OUT_FAILURE = 'LOG_OUT_FAILURE';

export const SIGN_UP_REQUEST = 'SIGN_UP_REQUEST';
export const SIGN_UP_SUCCESS = 'SIGN_UP_SUCCESS';
export const SIGN_UP_FAILURE = 'SIGN_UP_FAILURE';

export const LOAD_USERS_REQUEST = 'LOAD_USERS_REQUEST';
export const LOAD_USERS_SUCCESS = 'LOAD_USERS_SUCCESS';
export const LOAD_USERS_FAILURE = 'LOAD_USERS_FAILURE';

export const UPDATE_NICKNAME_REQUEST = 'UPDATE_NICKNAME_REQUEST';
export const UPDATE_NICKNAME_SUCCESS = 'UPDATE_NICKNAME_SUCCESS';
export const UPDATE_NICKNAME_FAILURE = 'UPDATE_NICKNAME_FAILURE';

export const DELETE_USER_REQUEST = 'DELETE_USER_REQUEST';
export const DELETE_USER_SUCCESS = 'DELETE_USER_SUCCESS';
export const DELETE_USER_FAILURE = 'DELETE_USER_FAILURE';


// 이메일 중복 확인
export const CHECK_EMAIL_REQUEST = 'CHECK_EMAIL_REQUEST';
export const CHECK_EMAIL_SUCCESS = 'CHECK_EMAIL_SUCCESS';
export const CHECK_EMAIL_FAILURE = 'CHECK_EMAIL_FAILURE';


// 닉네임 중복 확인
export const CHECK_NICKNAME_REQUEST = 'CHECK_NICKNAME_REQUEST';
export const CHECK_NICKNAME_SUCCESS = 'CHECK_NICKNAME_SUCCESS';
export const CHECK_NICKNAME_FAILURE = 'CHECK_NICKNAME_FAILURE';


// 중복 확인 초기화
export const RESET_EMAIL_CHECK = 'RESET_EMAIL_CHECK';
export const RESET_NICKNAME_CHECK = 'RESET_NICKNAME_CHECK';


// 검색
export const SEARCH_USERS_REQUEST = 'SEARCH_USERS_REQUEST';
export const SEARCH_USERS_SUCCESS = 'SEARCH_USERS_SUCCESS';
export const SEARCH_USERS_FAILURE = 'SEARCH_USERS_FAILURE';



export const initialState = {

    me:null,

    users:[],

    isLoading:false,

    error:null,

    signUpDone:false,


    // 이메일 체크
    checkEmailLoading:false,
    checkEmailDone:false,
    checkEmailError:null,
    isEmailAvailable:null,


    // 닉네임 체크
    checkNicknameLoading:false,
    checkNicknameDone:false,
    checkNicknameError:null,
    isNicknameAvailable:null,


    // 검색
    searchResults:[],
    searchUsersLoading:false,
    searchUsersDone:false,
    searchUsersError:null,

};



const reducer = (state = initialState , action)=>{


switch(action.type){



// ---------------- 요청 ----------------

case LOG_IN_REQUEST:
case LOG_OUT_REQUEST:
case SIGN_UP_REQUEST:
case LOAD_USERS_REQUEST:
case UPDATE_NICKNAME_REQUEST:
case DELETE_USER_REQUEST:

    return {
        ...state,
        isLoading:true,
        error:null
    };



case CHECK_EMAIL_REQUEST:

    return {
        ...state,
        checkEmailLoading:true,
        checkEmailDone:false,
        checkEmailError:null,
        isEmailAvailable:null
    };



// 이메일 초기화
case RESET_EMAIL_CHECK:

    return {
        ...state,
        checkEmailLoading:false,
        checkEmailDone:false,
        checkEmailError:null,
        isEmailAvailable:null
    };



// 닉네임 초기화
case RESET_NICKNAME_CHECK:

    return {
        ...state,
        checkNicknameLoading:false,
        checkNicknameDone:false,
        checkNicknameError:null,
        isNicknameAvailable:null
    };





// ---------------- 성공 ----------------


case LOG_IN_SUCCESS:

    return {
        ...state,
        isLoading:false,
        me:action.data
    };



case LOG_OUT_SUCCESS:

    return {
        ...state,
        isLoading:false,
        me:null
    };



case SIGN_UP_SUCCESS:

    return {
        ...state,
        isLoading:false,
        signUpDone:true
    };



case LOAD_USERS_SUCCESS:

    return {
        ...state,
        isLoading:false,
        users:action.data,
        searchResults:[],
        searchUsersDone:false,
        searchUsersError:null
    };




// 이메일 중복 성공

case CHECK_EMAIL_SUCCESS:

    return {
        ...state,
        checkEmailLoading:false,
        checkEmailDone:true,
        isEmailAvailable:action.data.isAvailable
    };



// 이메일 실패

case CHECK_EMAIL_FAILURE:

    return {
        ...state,
        checkEmailLoading:false,
        checkEmailError:action.error,
        isEmailAvailable:null
    };





// 닉네임 중복

case CHECK_NICKNAME_REQUEST:

    return {
        ...state,
        checkNicknameLoading:true,
        checkNicknameDone:false,
        checkNicknameError:null,
        isNicknameAvailable:null
    };



case CHECK_NICKNAME_SUCCESS:

    return {
        ...state,
        checkNicknameLoading:false,
        checkNicknameDone:true,
        isNicknameAvailable:action.data.isAvailable
    };



case CHECK_NICKNAME_FAILURE:

    return {
        ...state,
        checkNicknameLoading:false,
        checkNicknameError:action.error,
        isNicknameAvailable:null
    };






// 닉네임 수정

case UPDATE_NICKNAME_SUCCESS:

    return {

        ...state,

        isLoading:false,


        me:
        state.me && state.me.id === action.data.id
        ?
        {
            ...state.me,
            nickname:action.data.nickname
        }
        :
        state.me,


        users:
        state.users.map((u)=>
            u.id === action.data.id
            ?
            {
                ...u,
                nickname:action.data.nickname
            }
            :
            u
        ),


        searchResults:
        state.searchResults.map((u)=>
            u.id === action.data.id
            ?
            {
                ...u,
                nickname:action.data.nickname
            }
            :
            u
        )

    };





// 삭제

case DELETE_USER_SUCCESS:


    return {

        ...state,

        isLoading:false,


        users:
        state.users.filter(
            (u)=>u.id !== action.data.id
        ),


        searchResults:
        state.searchResults.filter(
            (u)=>u.id !== action.data.id
        ),


        me:
        state.me?.id === action.data.id
        ?
        null
        :
        state.me

    };






// 검색

case SEARCH_USERS_REQUEST:


    return {

        ...state,

        searchUsersLoading:true,

        searchUsersDone:false,

        searchUsersError:null

    };



case SEARCH_USERS_SUCCESS:


    return {

        ...state,

        searchUsersLoading:false,

        searchUsersDone:true,

        searchResults:action.data

    };



case SEARCH_USERS_FAILURE:


    return {

        ...state,

        searchUsersLoading:false,

        searchUsersError:action.error

    };





// ---------------- 실패 ----------------


case LOG_IN_FAILURE:
case LOG_OUT_FAILURE:
case SIGN_UP_FAILURE:
case LOAD_USERS_FAILURE:
case UPDATE_NICKNAME_FAILURE:
case DELETE_USER_FAILURE:


return {

    ...state,

    isLoading:false,

    error:action.error?.message || action.error

};





default:

return state;


}



};


export default reducer;